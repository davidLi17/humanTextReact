var k=Object.defineProperty;var D=(c,l,a)=>l in c?k(c,l,{enumerable:!0,configurable:!0,writable:!0,value:a}):c[l]=a;var s=(c,l,a)=>D(c,typeof l!="symbol"?l+"":l,a);var content=(function(){"use strict";var w,S;function c(o){return o}const a=(S=(w=globalThis.browser)==null?void 0:w.runtime)!=null&&S.id?globalThis.browser:globalThis.chrome,T=`
  .translator-popup {
    position: fixed;
    z-index: 10000;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    max-width: none;
    min-width: 300px;
    font-family: system-ui, -apple-system, sans-serif;
    max-height: 80vh;
    cursor: default;
    width: 400px;
    overflow: hidden;
  }

  .translator-popup::after {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 15px;
    height: 100%;
    cursor: e-resize;
    z-index: 2;
  }
  
  .translator-popup::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 15px;
    height: 100%;
    cursor: w-resize;
    z-index: 2;
  }

  .translator-popup .translator-header {
    position: sticky;
    top: 0;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: white;
    border-bottom: 1px solid #eee;
    border-radius: 8px 8px 0 0;
    cursor: grab;
    user-select: none;
  }

  .translator-popup .translator-header:active {
    cursor: grabbing;
  }

  .translator-popup .translator-title {
    font-weight: bold;
    color: #333;
  }

  .translator-popup .translator-close-btn {
    cursor: pointer;
    padding: 4px;
    color: #666;
  }

  .translator-popup .translator-content {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    scroll-behavior: smooth;
    max-height: calc(80vh - 100px);
    cursor: auto;
  }

  .translator-popup .translator-section {
    margin-bottom: 12px;
    padding: 12px;
    border-radius: 6px;
    background: #fff;
    position: relative;
  }

  .translator-popup .translator-section:last-child {
    margin-bottom: 0;
    padding-bottom: 40px;
  }

  .translator-popup .translator-copy-original-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    background: rgba(76, 175, 80, 0.1);
    color: #4CAF50;
    border: 1px solid #4CAF50;
    border-radius: 4px;
    padding: 4px 8px;
    font-size: 12px;
    cursor: pointer;
    opacity: 0.8;
    transition: all 0.2s ease;
  }

  .translator-popup .translator-copy-original-btn:hover {
    opacity: 1;
    background: rgba(76, 175, 80, 0.2);
  }

  .translator-popup .translator-label {
    font-size: 12px;
    color: #666;
    margin-bottom: 8px;
    font-weight: 500;
  }

  .translator-popup .translator-text {
    color: #333;
    line-height: 1.5;
    overflow-wrap: break-word;
  }

  .translator-popup .translator-reasoning-text {
    color: #666;
    line-height: 1.5;
    overflow-wrap: break-word;
    font-size: 0.95em;
    background: #f8f9fa;
    padding: 12px;
    border-radius: 4px;
    border-left: 3px solid #6c757d;
  }

  .translator-popup .translator-translated-text {
    color: #333;
    line-height: 1.5;
    overflow-wrap: break-word;
    font-weight: 500;
  }

  .translator-popup .translator-text p,
  .translator-popup .translator-reasoning-text p,
  .translator-popup .translator-translated-text p {
    margin: 0.5em 0;
  }

  .translator-popup .translator-text code,
  .translator-popup .translator-reasoning-text code,
  .translator-popup .translator-translated-text code {
    background: #f5f5f5;
    padding: 0.2em 0.4em;
    border-radius: 3px;
    font-size: 0.9em;
  }

  .translator-popup .translator-text pre,
  .translator-popup .translator-reasoning-text pre,
  .translator-popup .translator-translated-text pre {
    background: #f5f5f5;
    padding: 1em;
    border-radius: 6px;
    overflow-x: auto;
  }

  .translator-popup .translator-text blockquote,
  .translator-popup .translator-reasoning-text blockquote,
  .translator-popup .translator-translated-text blockquote {
    margin: 0.5em 0;
    padding-left: 1em;
    border-left: 4px solid #ddd;
    color: #666;
  }

  .translator-popup .translator-loading {
    display: inline-block;
    margin-left: 8px;
    color: #666;
  }

  .translator-popup .translator-copy-btn {
    position: sticky;
    bottom: 0;
    left: 0;
    right: 0;
    background: #4CAF50;
    color: white;
    border: none;
    padding: 8px 16px;
    width: 100%;
    cursor: pointer;
    border-radius: 0 0 8px 8px;
    margin-top: auto;
  }

  .translator-popup .translator-copy-btn:hover {
    background: #45a049;
  }

  .translator-popup.resizing-left {
    cursor: w-resize;
    user-select: none;
  }

  .translator-popup.resizing-right {
    cursor: e-resize;
    user-select: none;
  }

  .translator-popup .translator-content::-webkit-scrollbar {
    width: 8px;
  }

  .translator-popup .translator-content::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
  }

  .translator-popup .translator-content::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 4px;
  }

  .translator-popup .translator-content::-webkit-scrollbar-thumb:hover {
    background: #666;
  }

  .markdown-divider {
    border: none;
    border-top: 1px solid #e0e0e0;
    margin: 1.5em 0;
    opacity: 0.7;
  }
`;function y(){if(!document.querySelector("#translator-popup-style")){const o=document.createElement("style");o.id="translator-popup-style",o.textContent=T,document.head.appendChild(o)}}const p={TRANSLATE:"translate",CLEANUP:"cleanup",GET_HISTORY:"getHistory",CLEAR_HISTORY:"clearHistory",DELETE_HISTORY_ITEM:"deleteHistoryItem",IMPORT_HISTORY:"importHistory",UPDATE_TRANSLATION:"updateTranslation",SHOW_TRANSLATION_POPUP:"showTranslationPopup",GET_SELECTED_TEXT:"getSelectedText"};class P{constructor(t,e){s(this,"isDragging",!1);s(this,"isResizing",!1);s(this,"resizeDirection",null);s(this,"startX",0);s(this,"startY",0);s(this,"startWidth",0);s(this,"initialX",0);s(this,"initialY",0);s(this,"startLeft",0);s(this,"cleanup",null);s(this,"handleHeaderMouseDown",t=>{this.isDragging=!0,this.startX=t.clientX,this.startY=t.clientY,this.initialX=this.popup.offsetLeft,this.initialY=this.popup.offsetTop,t.preventDefault(),t.stopPropagation()});s(this,"handlePopupMouseDown",t=>{if(t.target.closest(".translator-header"))return;const e=this.popup.getBoundingClientRect(),r=t.clientX-e.left,n=e.right-t.clientX;r<=15?(this.isResizing=!0,this.resizeDirection="left",this.startWidth=this.popup.offsetWidth,this.startX=t.clientX,this.startLeft=this.popup.offsetLeft,this.popup.classList.add("resizing-left"),t.preventDefault(),t.stopPropagation()):n<=15&&(this.isResizing=!0,this.resizeDirection="right",this.startWidth=this.popup.offsetWidth,this.startX=t.clientX,this.popup.classList.add("resizing-right"),t.preventDefault(),t.stopPropagation())});s(this,"handleMouseMove",t=>{this.isResizing?this.handleResize(t):this.isDragging&&this.handleDrag(t)});s(this,"handleMouseUp",t=>{this.isResizing&&(this.isResizing=!1,this.resizeDirection=null,this.popup.classList.remove("resizing-left","resizing-right"),this.savePopupState(),t.preventDefault(),t.stopPropagation()),this.isDragging&&(this.isDragging=!1,this.savePopupState())});this.popup=t,this.onStateChange=e,this.initializeEvents()}initializeEvents(){this.popup.querySelector(".translator-header").addEventListener("mousedown",this.handleHeaderMouseDown,!0),this.popup.addEventListener("mousedown",this.handlePopupMouseDown,!0),this.setupCopyButtons(),document.addEventListener("mousemove",this.handleMouseMove,!0),document.addEventListener("mouseup",this.handleMouseUp,!0),this.cleanup=()=>{document.removeEventListener("mousemove",this.handleMouseMove,!0),document.removeEventListener("mouseup",this.handleMouseUp,!0)}}handleResize(t){let e;if(this.resizeDirection==="right"){const r=t.clientX-this.startX;e=this.startWidth+r}else if(this.resizeDirection==="left"){const r=this.startX-t.clientX;e=this.startWidth+r}else return;if(e=Math.min(Math.max(300,e),1200),this.popup.style.width=`${e}px`,this.resizeDirection==="left"){const r=this.startLeft-(e-this.startWidth);this.popup.style.left=`${r}px`}t.preventDefault(),t.stopPropagation()}handleDrag(t){const e=t.clientX-this.startX,r=t.clientY-this.startY;this.popup.style.left=`${this.initialX+e}px`,this.popup.style.top=`${this.initialY+r}px`,t.preventDefault(),t.stopPropagation()}setupCopyButtons(){const t=this.popup.querySelector(".translator-copy-btn");t==null||t.addEventListener("click",()=>{var n;const r=((n=this.popup.querySelector(".translator-translated-text"))==null?void 0:n.textContent)||"";this.copyToClipboard(r,t,"复制译文")});const e=this.popup.querySelector(".translator-copy-original-btn");e==null||e.addEventListener("click",()=>{var n;const r=((n=this.popup.querySelector(".translator-text"))==null?void 0:n.textContent)||"";this.copyToClipboard(r,e,"复制")})}async copyToClipboard(t,e,r){try{await navigator.clipboard.writeText(t),e.textContent="已复制",setTimeout(()=>e.textContent=r,1500)}catch(n){console.error("复制失败:",n),alert("复制失败，请重试")}}savePopupState(){const t=parseInt(this.popup.style.left),e=parseInt(this.popup.style.top),r=parseInt(this.popup.style.width);!isNaN(t)&&!isNaN(e)&&!isNaN(r)&&this.onStateChange({left:t,top:e,width:r})}destroy(){this.cleanup&&this.cleanup()}}function b(o){if(!o)return"";let t=o;return t=t.replace(/</g,"&lt;").replace(/>/g,"&gt;"),t=t.replace(/```([\s\S]*?)```/g,"<pre><code>$1</code></pre>"),t=t.replace(/`([^`]+)`/g,"<code>$1</code>"),t=t.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),t=t.replace(/\*(.*?)\*/g,"<em>$1</em>"),t=t.replace(/^### (.*$)/gm,"<h3>$1</h3>"),t=t.replace(/^## (.*$)/gm,"<h2>$1</h2>"),t=t.replace(/^# (.*$)/gm,"<h1>$1</h1>"),t=t.replace(/^> (.*$)/gm,"<blockquote>$1</blockquote>"),t=t.replace(/^- (.*$)/gm,"<li>$1</li>"),t=t.replace(/(<li>.*<\/li>)/s,"<ul>$1</ul>"),t=t.replace(/\n/g,"<br>"),t=t.replace(/(<br>\s*){2,}/g,"</p><p>"),t="<p>"+t+"</p>",t=t.replace(/<p><\/p>/g,""),t=t.replace(/<p><br><\/p>/g,""),t}class M{constructor(){s(this,"lastPopupState",{left:null,top:null,width:null});s(this,"currentPopup",null);s(this,"eventHandler",null);s(this,"userHasScrolled",!1)}showPopup(t){this.removeCurrentPopup();const e=this.createPopupElement(t);return this.currentPopup=e,document.body.appendChild(e),this.positionPopup(e),this.setupEventHandlers(e),this.setupScrollDetection(e),e}updateTranslation(t){if(!this.currentPopup)return console.log("翻译弹窗不存在，可能已关闭"),!1;const e=this.getPopupElements();return!e.translatedTextEl||!e.reasoningTextEl||!e.loadingEl?!1:(t.error?this.handleTranslationError(t.error,e.loadingEl):this.handleTranslationUpdate(t,e),!0)}removeCurrentPopup(){this.currentPopup&&(this.savePopupState(this.currentPopup),this.eventHandler&&(this.eventHandler.destroy(),this.eventHandler=null),this.currentPopup.remove(),this.currentPopup=null)}createPopupElement(t){const e=document.createElement("div");return e.className="translator-popup",e.innerHTML=`
      <div class="translator-header">
        <div class="translator-title">人话翻译器</div>
        <div class="translator-close-btn">✕</div>
      </div>
      <div class="translator-content">
        <div class="translator-section">
          <div class="translator-label">原文</div>
          <div class="translator-text">${t}</div>
          <button class="translator-copy-original-btn">复制</button>
        </div>
        <div class="translator-section translator-section-reasoning" style="display: none;">
          <div class="translator-label">思维链</div>
          <div class="translator-reasoning-text"></div>
        </div>
        <div class="translator-section">
          <div class="translator-label">译文</div>
          <div class="translator-translated-text"></div>
          <div class="translator-loading">正在翻译...</div>
        </div>
      </div>
      <button class="translator-copy-btn">复制译文</button>
    `,e}positionPopup(t){const e=window.innerWidth,r=window.innerHeight;let n=e-420,i=20,u=400;this.lastPopupState.left!==null&&this.lastPopupState.top!==null&&(n=Math.min(Math.max(0,this.lastPopupState.left),e-300),i=Math.min(Math.max(0,this.lastPopupState.top),r-100)),this.lastPopupState.width!==null&&(u=Math.min(Math.max(300,this.lastPopupState.width),1200)),t.style.left=`${n}px`,t.style.top=`${i}px`,t.style.width=`${u}px`}setupEventHandlers(t){var e;this.eventHandler=new P(t,r=>{this.lastPopupState=r,console.log("保存弹窗状态:",r)}),(e=t.querySelector(".translator-close-btn"))==null||e.addEventListener("click",()=>{a.runtime.sendMessage({action:p.CLEANUP}),this.removeCurrentPopup()})}setupScrollDetection(t){const e=t.querySelector(".translator-content");this.userHasScrolled=!1,e.addEventListener("scroll",()=>{const r=e.scrollHeight-e.scrollTop<=e.clientHeight+1;this.userHasScrolled=!r}),t.userHasScrolled=()=>this.userHasScrolled}getPopupElements(){return this.currentPopup?{translatedTextEl:this.currentPopup.querySelector(".translator-translated-text"),reasoningSectionEl:this.currentPopup.querySelector(".translator-section-reasoning"),reasoningTextEl:this.currentPopup.querySelector(".translator-reasoning-text"),loadingEl:this.currentPopup.querySelector(".translator-loading"),contentEl:this.currentPopup.querySelector(".translator-content")}:{}}handleTranslationError(t,e){console.log("翻译发生错误:",t),t.includes("API Key")||t.includes("API 请求失败")||t.includes("rate limit")?e.textContent="翻译失败："+t:e.textContent="翻译失败，请重试"}handleTranslationUpdate(t,e){console.log("更新翻译结果"),t.content&&(e.translatedTextEl.innerHTML=b(t.content)),e.reasoningSectionEl&&(e.reasoningSectionEl.style.display=t.hasReasoning?"block":"none",t.hasReasoning&&t.reasoningContent&&(e.reasoningTextEl.innerHTML=b(t.reasoningContent))),t.done&&(console.log("翻译完成"),e.loadingEl.style.display="none"),!this.userHasScrolled&&e.contentEl&&(e.contentEl.scrollTop=e.contentEl.scrollHeight)}savePopupState(t){const e=parseInt(t.style.left),r=parseInt(t.style.top),n=parseInt(t.style.width);!isNaN(e)&&!isNaN(r)&&!isNaN(n)&&(this.lastPopupState={left:e,top:r,width:n})}}class I{constructor(t){s(this,"handleMessage",(t,e,r)=>{console.log("Content script收到消息:",t.action);try{switch(t.action){case p.SHOW_TRANSLATION_POPUP:return this.handleShowTranslationPopup(t,r);case p.UPDATE_TRANSLATION:return this.handleUpdateTranslation(t,r);case p.GET_SELECTED_TEXT:return this.handleGetSelectedText(r);default:return r({success:!1,error:"未知操作"}),!0}}catch(n){return console.error("处理消息错误:",n),r({success:!1,error:n.message}),!0}});this.popupManager=t}handleShowTranslationPopup(t,e){if(!t.text)return e({success:!1,error:"缺少文本参数"}),!0;const r=document.querySelector(".translator-popup");return r?(console.log("发现旧的翻译弹窗，先移除"),a.runtime.sendMessage({action:p.CLEANUP},()=>{r.remove(),console.log("显示新弹窗"),this.popupManager.showPopup(t.text),a.runtime.sendMessage({action:p.TRANSLATE,text:t.text})})):(console.log("显示弹窗"),this.popupManager.showPopup(t.text),a.runtime.sendMessage({action:p.TRANSLATE,text:t.text})),e({success:!0}),!0}handleUpdateTranslation(t,e){const r=this.popupManager.updateTranslation(t);return e({success:r}),!0}handleGetSelectedText(t){var r;console.log("收到获取选中文本的消息");const e=(r=window.getSelection())==null?void 0:r.toString().trim();return console.log("选中的文本:",e),e?(console.log("直接显示弹框并开始翻译"),this.popupManager.showPopup(e),a.runtime.sendMessage({action:p.TRANSLATE,text:e})):console.log("没有选中文本"),t({success:!0}),!0}}const L={matches:["<all_urls>"],main(){console.log("人话翻译器 content script 启动"),y();const o=new M,t=new I(o);a.runtime.onMessage.addListener(t.handleMessage),console.log("Content script 初始化完成")}};function h(o,...t){}const N={debug:(...o)=>h(console.debug,...o),log:(...o)=>h(console.log,...o),warn:(...o)=>h(console.warn,...o),error:(...o)=>h(console.error,...o)},f=class f extends Event{constructor(t,e){super(f.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=e}};s(f,"EVENT_NAME",v("wxt:locationchange"));let m=f;function v(o){var t;return`${(t=a==null?void 0:a.runtime)==null?void 0:t.id}:content:${o}`}function C(o){let t,e;return{run(){t==null&&(e=new URL(location.href),t=o.setInterval(()=>{let r=new URL(location.href);r.href!==e.href&&(window.dispatchEvent(new m(r,e)),e=r)},1e3))}}}const d=class d{constructor(t,e){s(this,"isTopFrame",window.self===window.top);s(this,"abortController");s(this,"locationWatcher",C(this));s(this,"receivedMessageIds",new Set);this.contentScriptName=t,this.options=e,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return a.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,e){const r=setInterval(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(t,e){const r=setTimeout(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(t){const e=requestAnimationFrame((...r)=>{this.isValid&&t(...r)});return this.onInvalidated(()=>cancelAnimationFrame(e)),e}requestIdleCallback(t,e){const r=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},e);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(t,e,r,n){var i;e==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(i=t.addEventListener)==null||i.call(t,e.startsWith("wxt:")?v(e):e,r,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),N.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:d.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){var i,u,E;const e=((i=t.data)==null?void 0:i.type)===d.SCRIPT_STARTED_MESSAGE_TYPE,r=((u=t.data)==null?void 0:u.contentScriptName)===this.contentScriptName,n=!this.receivedMessageIds.has((E=t.data)==null?void 0:E.messageId);return e&&r&&n}listenForNewerScripts(t){let e=!0;const r=n=>{if(this.verifyScriptStartedEvent(n)){this.receivedMessageIds.add(n.data.messageId);const i=e;if(e=!1,i&&(t!=null&&t.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}};s(d,"SCRIPT_STARTED_MESSAGE_TYPE",v("wxt:content-script-started"));let x=d;function H(){}function g(o,...t){}const A={debug:(...o)=>g(console.debug,...o),log:(...o)=>g(console.log,...o),warn:(...o)=>g(console.warn,...o),error:(...o)=>g(console.error,...o)};return(async()=>{try{const{main:o,...t}=L,e=new x("content",t);return await o(e)}catch(o){throw A.error('The content script "content" crashed on startup!',o),o}})()})();
content;