var Y=Object.defineProperty;var q=(h,d,i)=>d in h?Y(h,d,{enumerable:!0,configurable:!0,writable:!0,value:i}):h[d]=i;var s=(h,d,i)=>q(h,typeof d!="symbol"?d+"":d,i);var content=(function(){"use strict";var y,T;function h(o){return o}const i=(T=(y=globalThis.browser)==null?void 0:y.runtime)!=null&&T.id?globalThis.browser:globalThis.chrome,P=`
  .translator-popup {
    position: fixed;
    z-index: 10000;
    background: white;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 6px rgba(0, 0, 0, 0.08);
    display: flex;
    flex-direction: column;
    max-width: none;
    min-width: 320px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
      "Helvetica Neue", Arial, sans-serif;
    max-height: 85vh;
    cursor: default;
    width: 420px;
    overflow: hidden;
    border: 1px solid rgba(0, 0, 0, 0.08);
    backdrop-filter: blur(8px);
  }

  .translator-popup::after {
    content: "";
    position: absolute;
    top: 0; 
    right: 0;
    width: 15px;
    height: 100%;
    cursor: e-resize;
    z-index: 2;
  }

  .translator-popup::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 15px;
    height: 100%;
    cursor: w-resize;
    z-index: 2;
  }

  .translator-popup .translator-header {
    position: sticky;
    top: 0;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    background: rgba(255, 255, 255, 0.95);
    border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    border-radius: 12px 12px 0 0;
    cursor: grab;
    user-select: none;
    backdrop-filter: blur(8px);
  }

  .translator-popup .translator-header:active {
    cursor: grabbing;
  }

  .translator-popup .translator-title {
    font-weight: 600;
    color: #1a1a1a;
    font-size: 15px;
  }

  .translator-popup .translator-close-btn {
    cursor: pointer;
    padding: 6px;
    color: #666;
    border-radius: 6px;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .translator-popup .translator-close-btn:hover {
    background: rgba(0, 0, 0, 0.08);
    color: #333;
  }

  .translator-popup .translator-content {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    scroll-behavior: smooth;
    max-height: calc(85vh - 120px);
    cursor: auto;
    line-height: 1.6;
  }

  .translator-popup .translator-section {
    margin-bottom: 16px;
    padding: 16px;
    border-radius: 8px;
    background: #fff;
    position: relative;
    border: 1px solid rgba(0, 0, 0, 0.05);
  }

  .translator-popup .translator-section:last-child {
    margin-bottom: 0;
    padding-bottom: 40px;
  }

  .translator-popup .translator-copy-original-btn {
    position: absolute;
    top: 12px;
    right: 12px;
    background: rgba(52, 199, 89, 0.1);
    color: #34c759;
    border: 1px solid rgba(52, 199, 89, 0.3);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    opacity: 0.8;
    transition: all 0.2s ease;
  }

  .translator-popup .translator-copy-original-btn:hover {
    opacity: 1;
    background: rgba(52, 199, 89, 0.15);
    transform: translateY(-1px);
  }

  .translator-popup .translator-label {
    font-size: 13px;
    color: #666;
    margin-bottom: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .translator-popup .translator-text {
    color: #1a1a1a;
    line-height: 1.6;
    overflow-wrap: break-word;
    font-size: 14px;
  }

  .translator-popup .translator-reasoning-text {
    color: #4a5568;
    line-height: 1.6;
    overflow-wrap: break-word;
    font-size: 13px;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 16px;
    border-radius: 8px;
    border-left: 4px solid #64748b;
    margin: 12px 0;
  }

  .translator-popup .translator-translated-text {
    color: #1a1a1a;
    line-height: 1.6;
    overflow-wrap: break-word;
    font-weight: 500;
    font-size: 14px;
  }

  /* Markdown 样式 */
  .translator-popup .markdown-paragraph {
    margin: 0.8em 0;
    color: #1a1a1a;
  }

  .translator-popup .markdown-paragraph:first-child {
    margin-top: 0;
  }

  .translator-popup .markdown-paragraph:last-child {
    margin-bottom: 0;
  }

  .translator-popup h1,
  .translator-popup h2,
  .translator-popup h3,
  .translator-popup h4,
  .translator-popup h5,
  .translator-popup h6 {
    margin: 1.2em 0 0.6em 0;
    font-weight: 600;
    line-height: 1.3;
    color: #1a1a1a;
  }

  .translator-popup h1 {
    font-size: 1.5em;
  }
  .translator-popup h2 {
    font-size: 1.3em;
  }
  .translator-popup h3 {
    font-size: 1.2em;
  }
  .translator-popup h4 {
    font-size: 1.1em;
  }
  .translator-popup h5 {
    font-size: 1em;
  }
  .translator-popup h6 {
    font-size: 0.95em;
  }

  .translator-popup .code-block {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    margin: 1em 0;
    overflow: hidden;
  }

  .translator-popup .code-block code {
    display: block;
    padding: 16px;
    overflow-x: auto;
    font-family: "SF Mono", Monaco, "Cascadia Code", "Roboto Mono", Consolas,
      "Courier New", monospace;
    font-size: 13px;
    line-height: 1.5;
    color: #2d3748;
    background: transparent;
  }

  .translator-popup .inline-code {
    background: rgba(107, 114, 126, 0.1);
    color: #d63384;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.9em;
    font-family: "SF Mono", Monaco, "Cascadia Code", "Roboto Mono", Consolas,
      "Courier New", monospace;
    font-weight: 500;
  }

  .translator-popup .markdown-list {
    margin: 1em 0;
    padding-left: 0;
  }

  .translator-popup .list-item {
    margin: 0.4em 0;
    padding-left: 1.5em;
    position: relative;
  }

  .translator-popup ul.markdown-list .list-item::before {
    content: "•";
    position: absolute;
    left: 0.5em;
    color: #64748b;
    font-weight: bold;
  }

  .translator-popup ol.markdown-list {
    counter-reset: list-counter;
  }

  .translator-popup ol.markdown-list .list-item {
    counter-increment: list-counter;
  }

  .translator-popup ol.markdown-list .list-item::before {
    content: counter(list-counter) ".";
    position: absolute;
    left: 0;
    color: #64748b;
    font-weight: 600;
    min-width: 1.2em;
  }

  .translator-popup .list-item.level-1 {
    padding-left: 2.5em;
  }
  .translator-popup .list-item.level-2 {
    padding-left: 3.5em;
  }
  .translator-popup .list-item.level-3 {
    padding-left: 4.5em;
  }

  .translator-popup .markdown-quote {
    margin: 1em 0;
    padding: 12px 16px;
    background: linear-gradient(135deg, #fef7cd 0%, #fef3c7 100%);
    border-left: 4px solid #f59e0b;
    border-radius: 0 8px 8px 0;
    font-style: italic;
    color: #92400e;
  }

  .translator-popup .markdown-table {
    width: 100%;
    border-collapse: collapse;
    margin: 1em 0;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #e2e8f0;
  }

  .translator-popup .markdown-table th {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 12px;
    text-align: left;
    font-weight: 600;
    color: #1a1a1a;
    border-bottom: 2px solid #e2e8f0;
  }

  .translator-popup .markdown-table td {
    padding: 10px 12px;
    border-bottom: 1px solid #f1f5f9;
  }

  .translator-popup .markdown-table tr:last-child td {
    border-bottom: none;
  }

  .translator-popup .markdown-table tr:nth-child(even) {
    background: rgba(248, 250, 252, 0.5);
  }

  .translator-popup .markdown-link {
    color: #3b82f6;
    text-decoration: none;
    border-bottom: 1px solid transparent;
    transition: all 0.2s ease;
  }

  .translator-popup .markdown-link:hover {
    color: #1d4ed8;
    border-bottom-color: #3b82f6;
  }

  .translator-popup .markdown-image {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1em 0;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .translator-popup .bold {
    font-weight: 600;
    color: #1a1a1a;
  }

  .translator-popup .italic {
    font-style: italic;
  }

  .translator-popup .strikethrough {
    text-decoration: line-through;
    color: #6b7280;
  }

  .translator-popup .highlight {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    padding: 2px 4px;
    border-radius: 4px;
    color: #92400e;
  }

  .translator-popup .markdown-divider {
    border: none;
    border-top: 2px solid #e2e8f0;
    margin: 2em 0;
    opacity: 0.8;
    background: linear-gradient(
      90deg,
      transparent 0%,
      #e2e8f0 50%,
      transparent 100%
    );
    height: 1px;
  }

  .translator-popup .translator-loading {
    display: inline-block;
    margin-left: 8px;
    color: #64748b;
    font-size: 13px;
  }

  .translator-popup .translator-copy-btn {
    position: sticky;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(135deg, #34c759 0%, #30d158 100%);
    color: white;
    border: none;
    padding: 12px 20px;
    width: 100%;
    cursor: pointer;
    border-radius: 0 0 12px 12px;
    margin-top: auto;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.2s ease;
  }

  .translator-popup .translator-copy-btn:hover {
    background: linear-gradient(135deg, #30b454 0%, #2bc653 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(52, 199, 89, 0.3);
  }

  .translator-popup.resizing-left {
    cursor: w-resize;
    user-select: none;
  }

  .translator-popup.resizing-right {
    cursor: e-resize;
    user-select: none;
  }

  .translator-popup .translator-content::-webkit-scrollbar {
    width: 6px;
  }

  .translator-popup .translator-content::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 3px;
  }

  .translator-popup .translator-content::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
    transition: background 0.2s ease;
  }

  .translator-popup .translator-content::-webkit-scrollbar-thumb:hover {
    background: rgba(0, 0, 0, 0.3);
  }

  /* 暗黑模式支持 */
  @media (prefers-color-scheme: dark) {
    .translator-popup {
      background: #1a1a1a;
      border-color: rgba(255, 255, 255, 0.1);
      color: #e5e5e5;
    }

    .translator-popup .translator-header {
      background: rgba(26, 26, 26, 0.95);
      border-bottom-color: rgba(255, 255, 255, 0.1);
    }

    .translator-popup .translator-title {
      color: #e5e5e5;
    }

    .translator-popup .translator-text,
    .translator-popup .translator-translated-text {
      color: #e5e5e5;
    }

    .translator-popup .translator-reasoning-text {
      background: linear-gradient(135deg, #2a2a2a 0%, #333 100%);
      color: #b0b0b0;
      border-left-color: #666;
    }

    .translator-popup .code-block {
      background: linear-gradient(135deg, #2a2a2a 0%, #333 100%);
      border-color: #444;
    }

    .translator-popup .code-block code {
      color: #e5e5e5;
    }

    .translator-popup .inline-code {
      background: rgba(255, 255, 255, 0.1);
      color: #ff6b9d;
    }

    .translator-popup .markdown-quote {
      background: linear-gradient(135deg, #2d1b0a 0%, #3d2a0f 100%);
      color: #d97706;
    }

    .translator-popup .markdown-table th {
      background: linear-gradient(135deg, #2a2a2a 0%, #333 100%);
      color: #e5e5e5;
      border-bottom-color: #444;
    }

    .translator-popup .markdown-table {
      border-color: #444;
    }

    .translator-popup .markdown-table td {
      border-bottom-color: #333;
    }

    .translator-popup .markdown-table tr:nth-child(even) {
      background: rgba(255, 255, 255, 0.05);
    }
  }

  /* 响应式设计 */
  @media (max-width: 480px) {
    .translator-popup {
      width: calc(100vw - 40px);
      max-width: none;
      left: 20px !important;
      right: 20px !important;
    }
  }
`;function M(){if(!document.querySelector("#translator-popup-style")){const o=document.createElement("style");o.id="translator-popup-style",o.textContent=P,document.head.appendChild(o)}}const u={TRANSLATE:"translate",CLEANUP:"cleanup",GET_HISTORY:"getHistory",CLEAR_HISTORY:"clearHistory",DELETE_HISTORY_ITEM:"deleteHistoryItem",IMPORT_HISTORY:"importHistory",UPDATE_TRANSLATION:"updateTranslation",SHOW_TRANSLATION_POPUP:"showTranslationPopup",GET_SELECTED_TEXT:"getSelectedText"};class ${constructor(t,e){s(this,"isDragging",!1);s(this,"isResizing",!1);s(this,"resizeDirection",null);s(this,"startX",0);s(this,"startY",0);s(this,"startWidth",0);s(this,"initialX",0);s(this,"initialY",0);s(this,"startLeft",0);s(this,"cleanup",null);s(this,"handleHeaderMouseDown",t=>{this.isDragging=!0,this.startX=t.clientX,this.startY=t.clientY,this.initialX=this.popup.offsetLeft,this.initialY=this.popup.offsetTop,t.preventDefault(),t.stopPropagation()});s(this,"handlePopupMouseDown",t=>{if(t.target.closest(".translator-header"))return;const e=this.popup.getBoundingClientRect(),r=t.clientX-e.left,n=e.right-t.clientX;r<=15?(this.isResizing=!0,this.resizeDirection="left",this.startWidth=this.popup.offsetWidth,this.startX=t.clientX,this.startLeft=this.popup.offsetLeft,this.popup.classList.add("resizing-left"),t.preventDefault(),t.stopPropagation()):n<=15&&(this.isResizing=!0,this.resizeDirection="right",this.startWidth=this.popup.offsetWidth,this.startX=t.clientX,this.popup.classList.add("resizing-right"),t.preventDefault(),t.stopPropagation())});s(this,"handleMouseMove",t=>{this.isResizing?this.handleResize(t):this.isDragging&&this.handleDrag(t)});s(this,"handleMouseUp",t=>{this.isResizing&&(this.isResizing=!1,this.resizeDirection=null,this.popup.classList.remove("resizing-left","resizing-right"),this.savePopupState(),t.preventDefault(),t.stopPropagation()),this.isDragging&&(this.isDragging=!1,this.savePopupState())});this.popup=t,this.onStateChange=e,this.initializeEvents()}initializeEvents(){this.popup.querySelector(".translator-header").addEventListener("mousedown",this.handleHeaderMouseDown,!0),this.popup.addEventListener("mousedown",this.handlePopupMouseDown,!0),this.setupCopyButtons(),document.addEventListener("mousemove",this.handleMouseMove,!0),document.addEventListener("mouseup",this.handleMouseUp,!0),this.cleanup=()=>{document.removeEventListener("mousemove",this.handleMouseMove,!0),document.removeEventListener("mouseup",this.handleMouseUp,!0)}}handleResize(t){let e;if(this.resizeDirection==="right"){const r=t.clientX-this.startX;e=this.startWidth+r}else if(this.resizeDirection==="left"){const r=this.startX-t.clientX;e=this.startWidth+r}else return;if(e=Math.min(Math.max(300,e),1200),this.popup.style.width=`${e}px`,this.resizeDirection==="left"){const r=this.startLeft-(e-this.startWidth);this.popup.style.left=`${r}px`}t.preventDefault(),t.stopPropagation()}handleDrag(t){const e=t.clientX-this.startX,r=t.clientY-this.startY;this.popup.style.left=`${this.initialX+e}px`,this.popup.style.top=`${this.initialY+r}px`,t.preventDefault(),t.stopPropagation()}setupCopyButtons(){const t=this.popup.querySelector(".translator-copy-btn");t==null||t.addEventListener("click",()=>{var n;const r=((n=this.popup.querySelector(".translator-translated-text"))==null?void 0:n.textContent)||"";this.copyToClipboard(r,t,"复制译文")});const e=this.popup.querySelector(".translator-copy-original-btn");e==null||e.addEventListener("click",()=>{var n;const r=((n=this.popup.querySelector(".translator-text"))==null?void 0:n.textContent)||"";this.copyToClipboard(r,e,"复制")})}async copyToClipboard(t,e,r){try{await navigator.clipboard.writeText(t),e.textContent="已复制",setTimeout(()=>e.textContent=r,1500)}catch(n){console.error("复制失败:",n),alert("复制失败，请重试")}}savePopupState(){const t=parseInt(this.popup.style.left),e=parseInt(this.popup.style.top),r=parseInt(this.popup.style.width);!isNaN(t)&&!isNaN(e)&&!isNaN(r)&&this.onStateChange({left:t,top:e,width:r})}destroy(){this.cleanup&&this.cleanup()}}function S(o){if(!o)return"";let t=o;t=t.replace(/\r\n/g,`
`).replace(/\r/g,`
`),t=t.replace(/</g,"&lt;").replace(/>/g,"&gt;");const e=[];t=t.replace(/```(\w+)?\n([\s\S]*?)```/g,(n,a,l)=>{const p=e.length,c=a||"text";return e.push(`<pre class="code-block"><code class="language-${c}">${l.trim()}</code></pre>`),`__CODE_BLOCK_${p}__`});const r=[];return t=t.replace(/`([^`\n]+)`/g,(n,a)=>{const l=r.length;return r.push(`<code class="inline-code">${a}</code>`),`__INLINE_CODE_${l}__`}),t=C(t),t=t.replace(/^#{6}\s+(.*$)/gm,"<h6>$1</h6>"),t=t.replace(/^#{5}\s+(.*$)/gm,"<h5>$1</h5>"),t=t.replace(/^#{4}\s+(.*$)/gm,"<h4>$1</h4>"),t=t.replace(/^#{3}\s+(.*$)/gm,"<h3>$1</h3>"),t=t.replace(/^#{2}\s+(.*$)/gm,"<h2>$1</h2>"),t=t.replace(/^#{1}\s+(.*$)/gm,"<h1>$1</h1>"),t=t.replace(/^(-{3,}|\*{3,}|_{3,})$/gm,'<hr class="markdown-divider">'),t=L(t),t=I(t),t=_(t),t=N(t),t=z(t),e.forEach((n,a)=>{t=t.replace(`__CODE_BLOCK_${a}__`,n)}),r.forEach((n,a)=>{t=t.replace(`__INLINE_CODE_${a}__`,n)}),t=t.replace(/\n{3,}/g,`

`),t=t.replace(/^\s+|\s+$/g,""),t}function C(o){const t=/^(\|.*\|)\n(\|[-\s|:]*\|)\n((?:\|.*\|\n?)*)/gm;return o.replace(t,(e,r,n,a)=>{const l=r.split("|").slice(1,-1).map(c=>`<th>${c.trim()}</th>`).join(""),p=a.trim().split(`
`).map(c=>`<tr>${c.split("|").slice(1,-1).map(X=>`<td>${X.trim()}</td>`).join("")}</tr>`).join("");return`<table class="markdown-table"><thead><tr>${l}</tr></thead><tbody>${p}</tbody></table>`})}function L(o){const t=o.split(`
`),e=[];let r=!1,n=[];for(const a of t)a.match(/^>\s/)?(r||(r=!0,n=[]),n.push(a.replace(/^>\s?/,""))):(r&&(e.push(`<blockquote class="markdown-quote">${n.join("<br>")}</blockquote>`),r=!1,n=[]),e.push(a));return r&&n.length>0&&e.push(`<blockquote class="markdown-quote">${n.join("<br>")}</blockquote>`),e.join(`
`)}function I(o){const t=o.split(`
`),e=[];let r=null;for(const n of t){const a=n.match(/^(\s*)[-*+]\s+(.+)$/),l=n.match(/^(\s*)\d+\.\s+(.+)$/);if(a){const[,p,c]=a,w=Math.floor(p.length/2);(!r||r.type!=="ul")&&(r&&e.push(f(r)),r={type:"ul",items:[]}),r.items.push(`<li class="list-item level-${w}">${c}</li>`)}else if(l){const[,p,c]=l,w=Math.floor(p.length/2);(!r||r.type!=="ol")&&(r&&e.push(f(r)),r={type:"ol",items:[]}),r.items.push(`<li class="list-item level-${w}">${c}</li>`)}else r&&(e.push(f(r)),r=null),e.push(n)}return r&&e.push(f(r)),e.join(`
`)}function f(o){return`<${o.type} class="markdown-list">${o.items.join("")}</${o.type}>`}function _(o){return o=o.replace(/~~(.*?)~~/g,'<del class="strikethrough">$1</del>'),o=o.replace(/\*\*(.*?)\*\*/g,'<strong class="bold">$1</strong>'),o=o.replace(new RegExp("(?<!\\*)\\*(?!\\*)([^*]+)\\*(?!\\*)","g"),'<em class="italic">$1</em>'),o=o.replace(/==(.*?)==/g,'<mark class="highlight">$1</mark>'),o}function N(o){return o=o.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,'<img src="$2" alt="$1" class="markdown-image" loading="lazy">'),o=o.replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" class="markdown-link" target="_blank" rel="noopener noreferrer">$1</a>'),o=o.replace(/<(https?:\/\/[^>]+)>/g,'<a href="$1" class="markdown-link auto-link" target="_blank" rel="noopener noreferrer">$1</a>'),o}function z(o){return o.split(/\n\s*\n/).map(e=>{if(e=e.trim(),!e)return"";if(e.match(/^<(h[1-6]|div|blockquote|ul|ol|table|pre|hr)/))return e;const r=e.split(`
`).filter(n=>n.trim());return r.length===1?`<p class="markdown-paragraph">${r[0]}</p>`:`<p class="markdown-paragraph">${r.join("<br>")}</p>`}).join(`

`)}class D{constructor(){s(this,"lastPopupState",{left:null,top:null,width:null});s(this,"currentPopup",null);s(this,"eventHandler",null);s(this,"userHasScrolled",!1)}showPopup(t){this.removeCurrentPopup();const e=this.createPopupElement(t);return this.currentPopup=e,document.body.appendChild(e),this.positionPopup(e),this.setupEventHandlers(e),this.setupScrollDetection(e),e}updateTranslation(t){if(!this.currentPopup)return console.log("翻译弹窗不存在，可能已关闭"),!1;const e=this.getPopupElements();return!e.translatedTextEl||!e.reasoningTextEl||!e.loadingEl?!1:(t.error?this.handleTranslationError(t.error,e.loadingEl):this.handleTranslationUpdate(t,e),!0)}removeCurrentPopup(){this.currentPopup&&(this.savePopupState(this.currentPopup),this.eventHandler&&(this.eventHandler.destroy(),this.eventHandler=null),this.currentPopup.remove(),this.currentPopup=null)}createPopupElement(t){const e=document.createElement("div");return e.className="translator-popup",e.innerHTML=`
      <div class="translator-header">
        <div class="translator-title">人话翻译器</div>
        <div class="translator-close-btn">✕</div>
      </div>
      <div class="translator-content">
        <div class="translator-section">
          <div class="translator-label">原文</div>
          <div class="translator-text">${t}</div>
          <button class="translator-copy-original-btn">复制</button>
        </div>
        <div class="translator-section translator-section-reasoning" style="display: none;">
          <div class="translator-label">思维链</div>
          <div class="translator-reasoning-text"></div>
        </div>
        <div class="translator-section">
          <div class="translator-label">译文</div>
          <div class="translator-translated-text"></div>
          <div class="translator-loading">正在翻译...</div>
        </div>
      </div>
      <button class="translator-copy-btn">复制译文</button>
    `,e}positionPopup(t){const e=window.innerWidth,r=window.innerHeight;let n=e-420,a=20,l=400;this.lastPopupState.left!==null&&this.lastPopupState.top!==null&&(n=Math.min(Math.max(0,this.lastPopupState.left),e-300),a=Math.min(Math.max(0,this.lastPopupState.top),r-100)),this.lastPopupState.width!==null&&(l=Math.min(Math.max(300,this.lastPopupState.width),1200)),t.style.left=`${n}px`,t.style.top=`${a}px`,t.style.width=`${l}px`}setupEventHandlers(t){var e;this.eventHandler=new $(t,r=>{this.lastPopupState=r,console.log("保存弹窗状态:",r)}),(e=t.querySelector(".translator-close-btn"))==null||e.addEventListener("click",()=>{i.runtime.sendMessage({action:u.CLEANUP}),this.removeCurrentPopup()})}setupScrollDetection(t){const e=t.querySelector(".translator-content");this.userHasScrolled=!1,e.addEventListener("scroll",()=>{const r=e.scrollHeight-e.scrollTop<=e.clientHeight+1;this.userHasScrolled=!r}),t.userHasScrolled=()=>this.userHasScrolled}getPopupElements(){return this.currentPopup?{translatedTextEl:this.currentPopup.querySelector(".translator-translated-text"),reasoningSectionEl:this.currentPopup.querySelector(".translator-section-reasoning"),reasoningTextEl:this.currentPopup.querySelector(".translator-reasoning-text"),loadingEl:this.currentPopup.querySelector(".translator-loading"),contentEl:this.currentPopup.querySelector(".translator-content")}:{}}handleTranslationError(t,e){console.log("翻译发生错误:",t),t.includes("API Key")||t.includes("API 请求失败")||t.includes("rate limit")?e.textContent="翻译失败："+t:e.textContent="翻译失败，请重试"}handleTranslationUpdate(t,e){console.log("更新翻译结果"),t.content&&(e.translatedTextEl.innerHTML=S(t.content)),e.reasoningSectionEl&&(e.reasoningSectionEl.style.display=t.hasReasoning?"block":"none",t.hasReasoning&&t.reasoningContent&&(e.reasoningTextEl.innerHTML=S(t.reasoningContent))),t.done&&(console.log("翻译完成"),e.loadingEl.style.display="none"),!this.userHasScrolled&&e.contentEl&&(e.contentEl.scrollTop=e.contentEl.scrollHeight)}savePopupState(t){const e=parseInt(t.style.left),r=parseInt(t.style.top),n=parseInt(t.style.width);!isNaN(e)&&!isNaN(r)&&!isNaN(n)&&(this.lastPopupState={left:e,top:r,width:n})}}class A{constructor(t){s(this,"handleMessage",(t,e,r)=>{console.log("Content script收到消息:",t.action);try{switch(t.action){case u.SHOW_TRANSLATION_POPUP:return this.handleShowTranslationPopup(t,r);case u.UPDATE_TRANSLATION:return this.handleUpdateTranslation(t,r);case u.GET_SELECTED_TEXT:return this.handleGetSelectedText(r);default:return r({success:!1,error:"未知操作"}),!0}}catch(n){return console.error("处理消息错误:",n),r({success:!1,error:n.message}),!0}});this.popupManager=t}handleShowTranslationPopup(t,e){if(!t.text)return e({success:!1,error:"缺少文本参数"}),!0;const r=document.querySelector(".translator-popup");return r?(console.log("发现旧的翻译弹窗，先移除"),i.runtime.sendMessage({action:u.CLEANUP},()=>{r.remove(),console.log("显示新弹窗"),this.popupManager.showPopup(t.text),i.runtime.sendMessage({action:u.TRANSLATE,text:t.text})})):(console.log("显示弹窗"),this.popupManager.showPopup(t.text),i.runtime.sendMessage({action:u.TRANSLATE,text:t.text})),e({success:!0}),!0}handleUpdateTranslation(t,e){const r=this.popupManager.updateTranslation(t);return e({success:r}),!0}handleGetSelectedText(t){var r;console.log("收到获取选中文本的消息");const e=(r=window.getSelection())==null?void 0:r.toString().trim();return console.log("选中的文本:",e),e?(console.log("直接显示弹框并开始翻译"),this.popupManager.showPopup(e),i.runtime.sendMessage({action:u.TRANSLATE,text:e})):console.log("没有选中文本"),t({success:!0}),!0}}const H={matches:["<all_urls>"],main(){console.log("人话翻译器 content script 启动"),M();const o=new D,t=new A(o);i.runtime.onMessage.addListener(t.handleMessage),console.log("Content script 初始化完成")}};function b(o,...t){}const R={debug:(...o)=>b(console.debug,...o),log:(...o)=>b(console.log,...o),warn:(...o)=>b(console.warn,...o),error:(...o)=>b(console.error,...o)},x=class x extends Event{constructor(t,e){super(x.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=e}};s(x,"EVENT_NAME",k("wxt:locationchange"));let v=x;function k(o){var t;return`${(t=i==null?void 0:i.runtime)==null?void 0:t.id}:content:${o}`}function U(o){let t,e;return{run(){t==null&&(e=new URL(location.href),t=o.setInterval(()=>{let r=new URL(location.href);r.href!==e.href&&(window.dispatchEvent(new v(r,e)),e=r)},1e3))}}}const g=class g{constructor(t,e){s(this,"isTopFrame",window.self===window.top);s(this,"abortController");s(this,"locationWatcher",U(this));s(this,"receivedMessageIds",new Set);this.contentScriptName=t,this.options=e,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return i.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,e){const r=setInterval(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(t,e){const r=setTimeout(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(t){const e=requestAnimationFrame((...r)=>{this.isValid&&t(...r)});return this.onInvalidated(()=>cancelAnimationFrame(e)),e}requestIdleCallback(t,e){const r=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},e);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(t,e,r,n){var a;e==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(a=t.addEventListener)==null||a.call(t,e.startsWith("wxt:")?k(e):e,r,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),R.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:g.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){var a,l,p;const e=((a=t.data)==null?void 0:a.type)===g.SCRIPT_STARTED_MESSAGE_TYPE,r=((l=t.data)==null?void 0:l.contentScriptName)===this.contentScriptName,n=!this.receivedMessageIds.has((p=t.data)==null?void 0:p.messageId);return e&&r&&n}listenForNewerScripts(t){let e=!0;const r=n=>{if(this.verifyScriptStartedEvent(n)){this.receivedMessageIds.add(n.data.messageId);const a=e;if(e=!1,a&&(t!=null&&t.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}};s(g,"SCRIPT_STARTED_MESSAGE_TYPE",k("wxt:content-script-started"));let E=g;function F(){}function m(o,...t){}const O={debug:(...o)=>m(console.debug,...o),log:(...o)=>m(console.log,...o),warn:(...o)=>m(console.warn,...o),error:(...o)=>m(console.error,...o)};return(async()=>{try{const{main:o,...t}=H,e=new E("content",t);return await o(e)}catch(o){throw O.error('The content script "content" crashed on startup!',o),o}})()})();
content;